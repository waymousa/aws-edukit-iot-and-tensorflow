---
title : "Configuration"
weight : 100
---

# Configuration
Find out how to create and organize your content quickly and intuitively.
