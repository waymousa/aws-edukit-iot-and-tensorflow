---
title : "Customize the code"
weight : 6
---

# Customize the code

In this section we will chaneg the command responder code so that it causes the Edukit LED's to light up.  This is called actuating the Edukit.  You can use the same approach to actuate any response the EduKit can handle, such as posting an MQTT message, activatying a motor or maching the state of machinery.

