---
title: "AWS Edukit IoT and Tensorflow"
weight: 0
---

# AWS Edukit IoT and Tensorflow

This workshop module will take you through the steps required to deploy and test a Tensorflow model on the AWS EduKit IoT device.  

At the end of the module your Edukit device will be able to detect and respond to keywords.